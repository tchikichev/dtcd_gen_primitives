# config


ports config
![](2023-01-25-19-26-54.png)


well_primitives.csv ["ports"] >> ports config

to implement:
* 'pair_vertical_directed_indication'
* 'pair_vertical_directed'
* 'single_center'


props::

files in folder props
