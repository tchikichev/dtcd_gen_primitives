import { version } from './../package.json';

export default {
  version,
  type: 'extension',
  target: ['PrimitiveLibraryPanel', 'LiveDashPanel'],
  title: 'Примитивы нефтедобывающей отрасли',
  name: 'ExtensionOilPrimitives',
};
