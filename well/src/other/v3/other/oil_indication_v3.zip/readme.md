# indication

## well

well_outPort.json - описание порта с всеми свойствами

well_outPort.json + oil_indicator_well_ext.json

только результирующие свойства
well_outPort.json + oil_indicator_well.json



## pad, dns, ....

ports.py -- ports description

oil_indicator.json == compatible indicator, result props only



## bugs 

dns, pad ... == no q_m3_day value